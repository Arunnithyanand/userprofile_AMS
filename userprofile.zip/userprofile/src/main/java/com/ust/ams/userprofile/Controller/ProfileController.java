package com.ust.ams.userprofile.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.ams.userprofile.Entity.Profile;
import com.ust.ams.userprofile.Service.ProfileService;

@RestController
@RequestMapping("ams/profile")
public class ProfileController {
	
	
	@Autowired
	ProfileService service;
	
	@GetMapping("/ping")
	public String msg()   
	{  
	return ("Welcome to Profile Page");  
	}  
	
	@GetMapping("/view") 
	private List<Profile> getAllProfile()   
	{  
	return service.getAllProfile();  
	}  

	@GetMapping("/view/{id}")  
	private Profile getProfile(@PathVariable("id") int id)   
	{  
	return service.getProfileById(id);  
	}  
	

}
