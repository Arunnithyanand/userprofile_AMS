package com.ust.ams.userprofile.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.ams.userprofile.Entity.Profile;
import com.ust.ams.userprofile.Repository.ProfileRepository;


@Service
public class ProfileService {

	
	@Autowired
	ProfileRepository repository;
	
	public List<Profile> getAllProfile()   
	{  
	List<Profile> profiles = new ArrayList<Profile>();  
	repository.findAll().forEach(profile -> profiles.add(profile));  
	return profiles;  
	}  
	
	public Profile getProfileById(int id)   
	{  
	return repository.findById(id).get();  
	}  
	
}
