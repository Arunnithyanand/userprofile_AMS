package com.ust.ams.userprofile.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ust.ams.userprofile.Entity.Profile;

public interface ProfileRepository extends MongoRepository<Profile,Integer>{
	
	

}
